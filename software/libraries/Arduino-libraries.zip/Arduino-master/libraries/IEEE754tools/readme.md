
IEEE754_tools.h contains a collection of bit-hacks to speed up a number of operations on floating pointnumbers on the Arduino.
If you don't need micro-second speedups do not use these code snippets.
in short: USE WITH CARE
